import React from 'react';
import ReactDOM from 'react-dom';
import Article from './article';
import './index.css';



ReactDOM.render(
  <Article/>,
  document.querySelector('article')
);
